//
//  bank.h
//
//

#ifndef __BANK_H__
#define __BANK_H__

#include "customer.h"
#include <queue>

class Bank {
public:
  Bank() = default;
  Bank(const ext_vector<int>& available) : avail(available), customers() { }
  
  ext_vector<int> get_avail() const { return avail; }
  bool is_avail(const ext_vector<int>& req) const { return req < avail; }
  
  // TODO: determine if alloc is safe
  bool is_safe(int id, const ext_vector<int>& req){ 
    // grant request to customer 
    if(!is_avail(req)){return false;}    
    if (req > avail) { return false; }

    const Customer* c = customers[id];
    if (c->needs_exceeded(req)) { return false; }
    bool check = false;
    // create copy of available resources
    ext_vector<int> new_bank = avail;
    // avail - the request 
    new_bank = new_bank - req;
    // roll back request
    for(size_t i = 0; i < avail.size(); ++i){
      if(i == id) continue; 
      if(new_bank >= customers[i]->create_req()){
         check = true;
      }
    }
    //check if it is safe
    return check; 
    
  }   

  bool req_approved(int id, const ext_vector<int>& req) {
    if(is_safe(id, req)){
      std::cout << "--->APPROVED\n";
      return true;
    }else{
      std::cout << "--->DENIED\n";
      return false;
    }
  }
  
  void add_customer(Customer* c) {
    customers.push_back(c);
    avail -= c->allocated();
  }
  
  void withdraw_resources(const ext_vector<int>& req) {
    if (!is_avail(req)) {
      pthread_mutex_lock(&mutex_);
      std::cerr << "WARNING: req: " << req << " is not available for withdrawing\n";
      pthread_mutex_unlock(&mutex_);
      return;
    }
    if (is_avail(req)) { avail -= req; }
  }
  void deposit_resources(const ext_vector<int>& req) { avail += req; }


  ext_vector<Customer*> get_customers() const { return customers; }
  
  void show() const {
    pthread_mutex_lock(&mutex_);
    std::cout << "avail: [" << avail << "]\n";
    pthread_mutex_unlock(&mutex_);
    
    for (Customer* c : customers) {
      c->show();
    }
    std::cout << "\n";
  }
  
  friend std::ostream& operator<<(std::ostream& os, const Bank& be) {
    be.show();
    return os;
  }

private:
  ext_vector<int> avail;
  ext_vector<Customer*> customers;
};

#endif /* Bank_h */